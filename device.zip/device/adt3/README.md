# android_device_askey_adt3-TWRP
